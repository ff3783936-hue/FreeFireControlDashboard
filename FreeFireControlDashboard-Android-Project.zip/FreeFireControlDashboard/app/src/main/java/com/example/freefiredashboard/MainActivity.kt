package com.example.freefiredashboard

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import java.util.Locale
import kotlin.random.Random

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 14, 22)
    private val panel = Color.rgb(23, 29, 42)
    private val gold = Color.rgb(242, 184, 75)
    private val muted = Color.rgb(157, 168, 187)
    private var running = false
    private var headshot = 95
    private var tick = 0
    private lateinit var status: TextView
    private lateinit var vpnValue: TextView
    private lateinit var headValue: TextView
    private lateinit var aimValue: TextView
    private lateinit var locationValue: TextView
    private lateinit var logValue: TextView
    private lateinit var startButton: Button
    private val handler = android.os.Handler()

    private val monitor = object : Runnable {
        override fun run() {
            if (running) {
                tick++
                val x = Random.nextDouble(-500.0, 500.0)
                val y = Random.nextDouble(-500.0, 500.0)
                locationValue.text = String.format(Locale.US, "X  %.2f     Y  %.2f", x, y)
                logValue.text = "Demo monitor active • Sample $tick\nNo game process is accessed."
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 16, 18, 16)
        background = rounded(panel)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 14 }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 26, 20, 24)
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("FF CONTROL", 12f, gold, true))
        page.addView(label("Gaming Dashboard", 28f, Color.WHITE, true))
        page.addView(label("SAFE SIMULATION MODE", 11f, muted, true).apply {
            setPadding(0, 4, 0, 22)
        })

        val statusCard = card()
        statusCard.addView(label("SYSTEM STATUS", 11f, muted, true))
        status = label("●  STOPPED", 20f, gold, true)
        statusCard.addView(status.apply { setPadding(0, 8, 0, 2) })
        statusCard.addView(label("Standalone demo • No game connection", 12f, muted))
        page.addView(statusCard)

        val vpnCard = card()
        vpnCard.addView(label("NETWORK PANEL", 12f, gold, true))
        vpnValue = label("VPN status: Not connected (demo)", 16f, Color.WHITE, true)
        vpnCard.addView(vpnValue.apply { setPadding(0, 10, 0, 10) })
        val vpnButton = button("SIMULATE VPN STATUS")
        vpnButton.setOnClickListener {
            vpnValue.text = if (vpnValue.text.contains("Not connected"))
                "VPN status: Connected (simulated)" else "VPN status: Not connected (demo)"
        }
        vpnCard.addView(vpnButton)
        page.addView(vpnCard)

        val aimCard = card()
        aimCard.addView(label("AIM / HEADSHOT SIMULATOR", 12f, gold, true))
        headValue = label("Headshot simulation rate: 95%", 15f, Color.WHITE, true)
        aimCard.addView(headValue.apply { setPadding(0, 12, 0, 4) })
        val seek = SeekBar(this).apply {
            max = 100
            progress = 95
            progressTintList = android.content.res.ColorStateList.valueOf(gold)
            thumbTintList = android.content.res.ColorStateList.valueOf(gold)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                headshot = p
                headValue.text = "Headshot simulation rate: $p%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        aimCard.addView(seek)
        aimValue = label("Aim adjustment: Demo only", 13f, muted)
        aimCard.addView(aimValue.apply { setPadding(0, 10, 0, 0) })
        page.addView(aimCard)

        val locationCard = card()
        locationCard.addView(label("PLAYER COORDINATE SIMULATOR", 12f, gold, true))
        locationValue = label("X  0.00     Y  0.00", 19f, Color.WHITE, true)
        locationCard.addView(locationValue.apply { setPadding(0, 12, 0, 6) })
        locationCard.addView(label("Random sample coordinates; not real player location.", 12f, muted))
        page.addView(locationCard)

        val controlCard = card()
        controlCard.addView(label("CONTROL CENTER", 12f, gold, true))
        startButton = button("START MONITOR")
        startButton.setOnClickListener { toggleMonitor() }
        controlCard.addView(startButton)
        val stop = button("RESET DEMO")
        stop.setOnClickListener {
            running = false
            handler.removeCallbacks(monitor)
            tick = 0
            status.text = "●  STOPPED"
            startButton.text = "START MONITOR"
            locationValue.text = "X  0.00     Y  0.00"
            logValue.text = "Waiting for demo session..."
            aimValue.text = "Aim adjustment: Demo only"
        }
        controlCard.addView(stop)
        page.addView(controlCard)

        val logCard = card()
        logCard.addView(label("LIVE MONITORING LOG", 12f, gold, true))
        logValue = label("Waiting for demo session...", 13f, muted)
        logCard.addView(logValue.apply { setPadding(0, 10, 0, 0) })
        page.addView(logCard)

        page.addView(label("This app is an independent simulator. It does not modify Free Fire, access game memory, change your IP, or provide anti-ban functionality.", 11f, muted).apply {
            setPadding(2, 4, 2, 8)
        })
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 13f
        setTextColor(Color.rgb(20, 20, 20))
        background = rounded(gold, 14f)
        setPadding(12, 10, 12, 10)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 8 }
    }

    private fun toggleMonitor() {
        running = !running
        if (running) {
            status.text = "●  RUNNING"
            startButton.text = "STOP MONITOR"
            aimValue.text = "Aim adjustment: simulated • $headshot%"
            logValue.text = "Demo monitor started.\nNo game process is accessed."
            handler.post(monitor)
        } else {
            handler.removeCallbacks(monitor)
            status.text = "●  STOPPED"
            startButton.text = "START MONITOR"
            logValue.text = "Demo monitor stopped."
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(monitor)
        super.onDestroy()
    }
}
